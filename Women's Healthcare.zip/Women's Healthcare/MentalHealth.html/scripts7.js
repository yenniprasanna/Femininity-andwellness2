document.addEventListener('DOMContentLoaded', function() {
    const interactionInfo = document.getElementById('interaction-info');
    const updateForm = document.getElementById('update-form');
    const selectedContactInput = document.getElementById('selectedContact');

    // Load stored interactions
    const interactions = JSON.parse(localStorage.getItem('interactions')) || {};

    function selectContact(contactType) {
        selectedContactInput.value = contactType;
        updateForm.classList.remove('hidden');
    }

    function hideForm() {
        updateForm.classList.add('hidden');
    }

    function updateInteraction(event) {
        event.preventDefault();
        const contactType = selectedContactInput.value;
        const lastInteraction = document.getElementById('lastInteraction').value;
        const nextReminder = document.getElementById('nextReminder').value;

        interactions[contactType] = {
            lastInteraction: lastInteraction,
            nextReminder: nextReminder
        };

        localStorage.setItem('interactions', JSON.stringify(interactions));

        displayInteractionInfo(contactType);
        hideForm();
    }

    function displayInteractionInfo(contactType) {
        const interaction = interactions[contactType];
        if (interaction) {
            interactionInfo.innerHTML = `<h3>${capitalizeFirstLetter(contactType)}</h3>
                <p>Last interaction: ${interaction.lastInteraction}</p>
                <p>Next reminder: ${interaction.nextReminder}</p>`;
        } else {
            interactionInfo.innerHTML = 'Select a contact to track interactions.';
        }
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    // Make the functions globally accessible
    window.updateInteraction = updateInteraction;
    window.selectContact = selectContact;
    window.hideForm = hideForm;

    // Display initial interaction info if available
    ['friend', 'family', 'therapist'].forEach(displayInteractionInfo);
});
