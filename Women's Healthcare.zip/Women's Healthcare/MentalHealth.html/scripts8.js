document.addEventListener('DOMContentLoaded', function() {
    const thoughtsContainer = document.getElementById('thoughts-list');

    function processThought() {
        const thoughtInput = document.getElementById('thought-input');
        const thoughtText = thoughtInput.value.trim();

        if (thoughtText) {
            const processedThought = categorizeAndReframe(thoughtText);
            addThoughtToList(processedThought);
            thoughtInput.value = '';
        }
    }

    function categorizeAndReframe(thought) {
        // Simple categorization and reframing logic for demonstration
        let category, reframe;
        
        if (thought.includes('always') || thought.includes('never')) {
            category = 'Black-and-White Thinking';
            reframe = 'Consider more balanced thoughts. Look for the grey areas.';
        } else if (thought.includes('worst') || thought.includes('disaster')) {
            category = 'Catastrophizing';
            reframe = 'What is the best-case scenario? What is most likely to happen?';
        } else {
            category = 'General Anxiety';
            reframe = 'Try to identify specific triggers and challenge your assumptions.';
        }

        return { thought, category, reframe };
    }

    function addThoughtToList({ thought, category, reframe }) {
        const thoughtElement = document.createElement('div');
        thoughtElement.className = 'thought';
        thoughtElement.innerHTML = `
            <p><strong>Original Thought:</strong> ${thought}</p>
            <p><strong>Category:</strong> ${category}</p>
            <p><strong>Reframed Thought:</strong> ${reframe}</p>
        `;
        thoughtsContainer.appendChild(thoughtElement);
    }

    window.processThought = processThought;
});
