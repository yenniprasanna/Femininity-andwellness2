window.onload = function() {
    const happyMusic = document.getElementById('happy-music');
    const calmMusic = document.getElementById('calm-music');
    const sadMusic = document.getElementById('sad-music');
    const energeticMusic = document.getElementById('energetic-music');
    const anxiousMusic = document.getElementById('anxious-music');

    const musicList = [happyMusic, calmMusic, sadMusic, energeticMusic, anxiousMusic];

    musicList.forEach(audio => {
        audio.addEventListener('play', function() {
            pauseOthers(audio);
        });
    });

    function pauseOthers(currentAudio) {
        musicList.forEach(audio => {
            if (audio !== currentAudio) {
                audio.pause();
                audio.currentTime = 0;
            }
        });
    }
};