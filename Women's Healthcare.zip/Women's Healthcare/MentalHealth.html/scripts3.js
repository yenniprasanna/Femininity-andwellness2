function analyzeText() {
    const journalEntry = document.getElementById('journal-entry').value;
    const feedback = document.getElementById('feedback');
    const cognitiveDistortions = {
        'catastrophizing': /worst|disaster|ruined|failure/,
        'black-and-white thinking': /always|never|everyone|no one|nothing/,
        'overgeneralization': /always|never|everybody|nobody/,
        'personalization': /my fault|blame|responsible/,
        'mind reading': /they think|they feel|they believe/
    };

    let foundDistortions = [];

    for (let distortion in cognitiveDistortions) {
        if (cognitiveDistortions[distortion].test(journalEntry)) {
            foundDistortions.push(distortion);
        }
    }

    if (foundDistortions.length > 0) {
        feedback.innerHTML = `
            <h2>Detected Cognitive Distortions</h2>
            <ul>
                ${foundDistortions.map(d => `<li>${d}</li>`).join('')}
            </ul>
            <p>Consider re-evaluating your thoughts and looking for more balanced perspectives.</p>
        `;
    } else {
        feedback.innerHTML = '<p>No cognitive distortions detected. Great job!</p>';
    }
}
